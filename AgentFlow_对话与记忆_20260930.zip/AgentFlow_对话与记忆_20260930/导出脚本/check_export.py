# -*- coding: utf-8 -*-
"""校验导出的 Markdown 结构是否干净。

围栏规则按 CommonMark：
- 开围栏：行首最多 3 空格 + 3 个及以上连续反引号（或波浪号），后面可以跟语言标识；
- 闭围栏：同字符、长度不小于开围栏、且整行除围栏外没有其它内容。
带语言标识的行只能开围栏、不能闭围栏，这是最容易判错的地方。
"""
import re
import sys

OPEN = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
CLOSE = re.compile(r"^ {0,3}(`{3,}|~{3,})\s*$")


def check(path: str) -> int:
    text = open(path, encoding="utf-8").read()
    lines = text.split("\n")
    tok = None
    swallowed = []
    for i, line in enumerate(lines, 1):
        if tok is None:
            m = OPEN.match(line)
            if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
                tok = m.group(1)
            continue
        m = CLOSE.match(line)
        if m and m.group(1)[0] == tok[0] and len(m.group(1)) >= len(tok):
            tok = None
            continue
        if line.startswith("## ") or line.startswith("### "):
            swallowed.append((i, line[:60]))

    print("{}".format(path))
    print("  {} 行 / {} KB".format(len(lines), len(text.encode("utf-8")) // 1024))
    print("  文件末尾围栏: {}".format("未闭合 —— 后面内容会被吞进代码块" if tok else "已闭合 ✅"))
    print("  围栏内出现的标题: {} 处{}".format(
        len(swallowed), "（来自工具输出/正文里的代码块，属正常）" if swallowed else ""))
    for i, l in swallowed[:3]:
        print("    {}: {}".format(i, l))
    return 1 if tok else 0


if __name__ == "__main__":
    sys.exit(max(check(p) for p in sys.argv[1:]))
