# -*- coding: utf-8 -*-
"""把 AgentFlow 的跨会话记忆导成可读清单。

记忆的物理形态是 chromadb 的 sqlite 向量库（data/{user}/memory/chromadb/），
二进制不可读，这里直接读库把每条记忆的文档与元数据摊平出来。

用法：py export_memory.py [--root D:\\study\\demo] [--out .]
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import sqlite3
import sys

META_COLS = {
    "string_value": "text",
    "int_value": "int",
    "float_value": "real",
    "bool_value": "int",
}


def read_store(db: str) -> list[dict]:
    con = sqlite3.connect("file:{}?mode=ro".format(db.replace("\\", "/")), uri=True)
    try:
        collections = {cid: name for cid, name in con.execute("select id, name from collections")}
        seg2col = {sid: cid for sid, cid in con.execute("select id, collection from segments")}
        recs: dict[str, dict] = {}
        for eid, seg, seq in con.execute("select id, segment_id, seq_id from embeddings"):
            recs[eid] = {"collection": collections.get(seg2col.get(seg, ""), "?"), "seq": seq, "meta": {}}
        for eid, key, sv, iv, fv, bv in con.execute(
            "select id, key, string_value, int_value, float_value, bool_value from embedding_metadata"
        ):
            if eid not in recs:
                continue
            if key == "chroma:document":
                recs[eid]["document"] = sv or ""
            else:
                val = sv if sv is not None else (iv if iv is not None else (fv if fv is not None else bv))
                recs[eid]["meta"][key] = val
        return [r for _, r in sorted(recs.items(), key=lambda kv: kv[1]["seq"])]
    finally:
        con.close()


def render(root: str) -> str:
    md = ["# AgentFlow 跨会话记忆清单", ""]
    md.append("导出时间：{}".format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    md.append("")
    md.append("记忆的物理形态是 chromadb 向量库（`data/{user_id}/memory/chromadb/`），"
              "本文件把库里的文档与元数据摊平成可读文本；原始库文件见同目录下的 `运行期记忆数据/`。")
    md.append("")

    data_dir = os.path.join(root, "data")
    users = sorted(os.listdir(data_dir)) if os.path.isdir(data_dir) else []
    total = 0
    for user in users:
        chroma = os.path.join(data_dir, user, "memory", "chromadb", "chroma.sqlite3")
        if not os.path.isfile(chroma):
            continue
        recs = read_store(chroma)
        md.append("## 用户 `{}` ・ {} 条记忆".format(user, len(recs)))
        md.append("")
        if not recs:
            md.append("_（库存在但没有任何记忆记录）_")
            md.append("")
            continue
        total += len(recs)
        for i, r in enumerate(recs, 1):
            md.append("### {}. {} ・ {}".format(
                i, r["meta"].get("project_key") or r["meta"].get("owner") or "未命名",
                r["meta"].get("kind") or r["collection"]))
            md.append("")
            md.append("| 字段 | 值 |")
            md.append("| --- | --- |")
            for k in sorted(r["meta"]):
                v = r["meta"][k]
                if isinstance(v, str) and len(v) > 120:
                    v = v[:120] + "…"
                md.append("| `{}` | {} |".format(k, v))
            md.append("")
            md.append("**记忆正文**")
            md.append("")
            md.append("> " + (r.get("document") or "").replace("\n", "\n> "))
            md.append("")
        md.append("")

    md.append("---")
    md.append("")
    md.append("> 共 {} 条记忆。由 `export_memory.py` 从 chromadb 库导出。".format(total))
    md.append("")
    return "\n".join(md)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
    ap.add_argument("--out", default=".")
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    md = render(root)
    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, "AgentFlow记忆清单.md")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(md)
    print("导出记忆清单 → {} ({:.0f} KB)".format(path, len(md.encode("utf-8")) / 1024))


if __name__ == "__main__":
    main()
