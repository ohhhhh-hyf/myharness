# -*- coding: utf-8 -*-
"""打包「对话记录 + AgentFlow 记忆」到桌面。

用法：py pack_to_desktop.py [--src .] [--desktop C:\\Users\\OMEN\\Desktop]
"""
from __future__ import annotations

import argparse
import datetime
import os
import sys
import zipfile

EXCLUDE_DIRS = {"__pycache__", ".git", ".pytest_cache", ".ruff_cache", ".idea", ".venv"}


def add_file(zf: zipfile.ZipFile, path: str, arcname: str, log: list):
    zf.write(path, arcname)
    log.append((arcname, os.path.getsize(path)))


def add_tree(zf: zipfile.ZipFile, src: str, arcprefix: str, log: list, only: str | None = None):
    for base, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in sorted(files):
            if only and not f.endswith(only):
                continue
            full = os.path.join(base, f)
            rel = os.path.relpath(full, src)
            add_file(zf, full, os.path.join(arcprefix, rel), log)


def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.abspath(os.path.join(here, "..", ".."))
    ap.add_argument("--src", default=here, help="导出文件所在目录")
    ap.add_argument("--root", default=root, help="AgentFlow 项目根目录")
    ap.add_argument("--desktop", default=os.path.join(os.path.expanduser("~"), "Desktop"))
    ap.add_argument("--name", default=None)
    a = ap.parse_args()

    stamp = datetime.datetime.now().strftime("%Y%m%d")
    prefix = "AgentFlow_对话与记忆_{}".format(stamp)
    zip_path = os.path.join(a.desktop, prefix + ".zip")
    log: list = []

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        # 1) 对话记录
        for f in sorted(os.listdir(a.src)):
            if f.endswith(".md") and f[:8].isdigit():
                add_file(zf, os.path.join(a.src, f), os.path.join(prefix, "对话记录", f), log)
        # 2) 记忆清单
        inv = os.path.join(a.src, "AgentFlow记忆清单.md")
        if os.path.isfile(inv):
            add_file(zf, inv, os.path.join(prefix, "AgentFlow记忆", "AgentFlow记忆清单.md"), log)
        # 3) 运行期记忆原始数据（chromadb 向量库 + 其它落盘）
        for user in sorted(os.listdir(os.path.join(a.root, "data"))):
            mem = os.path.join(a.root, "data", user, "memory")
            if os.path.isdir(mem):
                add_tree(zf, mem, os.path.join(prefix, "AgentFlow记忆", "运行期记忆数据", "data", user, "memory"), log)
        # 4) 记忆实现源码
        for rel in ("tools/memory", "domain/meeting/memory", "domain/notes/memory"):
            src = os.path.join(a.root, rel.replace("/", os.sep))
            if os.path.isdir(src):
                add_tree(zf, src, os.path.join(prefix, "AgentFlow记忆", "记忆实现源码", rel), log, only=".py")
        # 5) 导出脚本
        for f in ("export_session.py", "check_export.py", "export_memory.py", "pack_to_desktop.py"):
            p = os.path.join(a.src, f)
            if os.path.isfile(p):
                add_file(zf, p, os.path.join(prefix, "导出脚本", f), log)

    # 清单（把自己也列进去，行数和包内实际一致）
    total = sum(s for _, s in log)
    manifest_rel = os.path.join(prefix, "清单.md")
    lines = ["# {} 归档清单".format(prefix), "",
             "生成时间：{}".format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")), "",
             "| 文件 | 原始大小 |", "| --- | --- |"]
    lines += ["| `{}` | {:.0f} KB |".format(n, s / 1024) for n, s in log]
    lines += ["| `{}` | — |".format(manifest_rel), "",
              "共 {} 个文件，压缩前 {:.1f} MB，压缩后 {:.1f} MB。".format(
                  len(log) + 1, total / 1048576, os.path.getsize(zip_path) / 1048576), ""]
    manifest = "\n".join(lines)
    with open(os.path.join(a.src, "清单.md"), "w", encoding="utf-8") as fh:
        fh.write(manifest)
    # 把清单补进压缩包
    with zipfile.ZipFile(zip_path, "a", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(manifest_rel, manifest)

    print("已打包 → {}（{} 个文件，{:.1f} MB）".format(
        zip_path, len(log) + 1, os.path.getsize(zip_path) / 1048576))
    for n, s in log:
        print("  {:>8.0f} KB  {}".format(s / 1024, n))


if __name__ == "__main__":
    main()
