# -*- coding: utf-8 -*-
"""把 ZCode 会话记录导出成可读的 Markdown。

数据来源：~/.zcode/cli/db/db.sqlite 的 session / message / part 三张表。

用法示例：
    py export_session.py --recent 2              # 当前工作目录最近 2 个会话
    py export_session.py --session sess_782e4ee9 # 指定会话（前缀即可）
    py export_session.py --list                  # 只列出会话，不导出
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import re
import sqlite3
import sys

DEFAULT_DB = os.path.join(os.path.expanduser("~"), ".zcode", "cli", "db", "db.sqlite")

# 只导出对话正文相关的 part，其余（step-start / step-finish）是运行时噪音
NOISE_PARTS = {"step-start", "step-finish"}

# 围栏判定：带语言标识的行只能开围栏，闭围栏必须是同字符、不短于开围栏的整行
FENCE_OPEN = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
FENCE_CLOSE = re.compile(r"^ {0,3}(`{3,}|~{3,})\s*$")


def connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect("file:{}?mode=ro".format(db_path.replace("\\", "/")), uri=True)
    con.row_factory = sqlite3.Row
    return con


def ts(ms) -> str:
    if not ms:
        return "-"
    return datetime.datetime.fromtimestamp(ms / 1000).strftime("%Y-%m-%d %H:%M:%S")


def load_sessions(con, directory: str | None, limit: int, include_subagents: bool):
    q = ["select * from session where 1=1"]
    p: list = []
    if directory:
        q.append("and lower(directory) = lower(?)")
        p.append(directory)
    if not include_subagents:
        q.append("and task_type = 'interactive'")
    q.append("order by time_updated desc limit ?")
    p.append(limit)
    rows = list(con.execute(" ".join(q), p))
    out = []
    for r in rows:
        n = con.execute("select count(*) from message where session_id=?", (r["id"],)).fetchone()[0]
        if n:
            out.append(r)
    return out


def resolve_session(con, key: str):
    exact = con.execute("select * from session where id=?", (key,)).fetchone()
    if exact:
        return exact
    rows = list(con.execute("select * from session where id like ? order by time_updated desc", (key + "%",)))
    if not rows:
        sys.exit("找不到会话：{}".format(key))
    if len(rows) > 1:
        sys.exit("会话前缀不唯一，匹配到 {} 个：{}".format(len(rows), [r["id"] for r in rows]))
    return rows[0]


def message_rows(con, session_id: str):
    return list(
        con.execute(
            "select * from message where session_id=? order by sequence, time_created",
            (session_id,),
        )
    )


def parts_of(con, message_id: str):
    return [
        json.loads(r["data"])
        for r in con.execute(
            "select data from part where message_id=? order by sequence, time_created",
            (message_id,),
        )
    ]


def visible(msg: dict) -> bool:
    """过滤掉系统注入的提醒、待办提醒、压缩摘要等隐藏消息。"""
    sem = msg.get("semantics") or {}
    return sem.get("transcriptVisibility", "visible") == "visible"


def fence(text: str, lang: str = "") -> str:
    text = text or ""
    ticks = "```"
    while ticks in text:
        ticks += "`"
    return "{}{}\n{}\n{}".format(ticks, lang, text.rstrip("\n"), ticks)


def demote(text: str, levels: int = 2) -> str:
    """把对话正文里的标题降级，避免和导出的轮次标题（## / ###）撞层级。

    围栏代码块里的 # 是注释或内容，原样保留。判定按 CommonMark：
    带语言标识的行只能开围栏，闭围栏必须是同字符且不短于开围栏的整行反引号。
    """
    out = []
    tok = None
    for line in (text or "").splitlines():
        if tok is None:
            m = FENCE_OPEN.match(line)
            if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
                tok = m.group(1)
                out.append(line)
                continue
        else:
            m = FENCE_CLOSE.match(line)
            if m and m.group(1)[0] == tok[0] and len(m.group(1)) >= len(tok):
                tok = None
            out.append(line)
            continue
        if tok is None:
            m = re.match(r"^(#{1,6})(\s)", line)
            if m:
                n = min(6, len(m.group(1)) + levels)
                line = "#" * n + line[len(m.group(1)):]
        out.append(line)
    return "\n".join(out)


def diff_lines(text: str, sign: str, limit: int) -> str:
    """给多行替换内容逐行加 +/- 前缀，读起来才像 diff。"""
    body = text[:limit] if limit > 0 else text
    return "\n".join("{}{}".format(sign, l) for l in body.splitlines())


def tool_summary(name: str, inp) -> str:
    """用入参描述这次调用干了什么，比 state.title（就是工具名）有用。"""
    if not isinstance(inp, dict):
        return ""
    if name == "Bash":
        desc = inp.get("description")
        if desc:
            return str(desc)[:90]
        cmd = (inp.get("command") or "").strip().splitlines()
        return cmd[0][:90] if cmd else ""
    if name in ("Read", "Write", "Edit"):
        return str(inp.get("file_path", ""))[:100]
    if name == "Agent":
        return str(inp.get("description", ""))[:90]
    if name == "TodoWrite":
        todos = inp.get("todos") or []
        return "{} 项待办".format(len(todos)) if todos else ""
    if name == "AskUserQuestion":
        qs = inp.get("questions") or []
        return str(qs[0].get("question", ""))[:80] if qs else ""
    if name in ("Skill", "TaskStop", "TaskOutput"):
        return str(inp.get("skill") or inp.get("task_id") or "")[:60]
    return str(inp.get("description", ""))[:90]


def tool_block(part: dict, out_limit: int, when: str = "") -> str:
    name = part.get("tool") or "tool"
    state = part.get("state") or {}
    status = state.get("status") or "-"
    icon = {"completed": "✅", "error": "❌", "running": "⏳"}.get(status, "🔧")
    inp = state.get("input")
    summary = tool_summary(name, inp)
    head = "{} <b>{}</b>".format(icon, name)
    if summary:
        head += " · {}".format(summary)
    if when:
        head += " · {}".format(when)

    lines = ["<details>", "<summary>{}</summary>".format(head), ""]

    if inp is not None:
        if name == "Bash" and isinstance(inp, dict) and inp.get("command"):
            lines.append("**命令**")
            lines.append("")
            lines.append(fence(inp["command"], "bash"))
        elif name == "Edit" and isinstance(inp, dict):
            lines.append("**替换** `{}`".format(inp.get("file_path", "")))
            lines.append("")
            lines.append(fence(diff_lines(str(inp.get("old_string", "")), "-", out_limit)
                               + "\n" + diff_lines(str(inp.get("new_string", "")), "+", out_limit), "diff"))
        elif name == "Write" and isinstance(inp, dict):
            lines.append("**写入** `{}`".format(inp.get("file_path", "")))
            lines.append("")
            lines.append(fence(str(inp.get("content", ""))[:out_limit], "text"))
        else:
            lines.append("**入参**")
            lines.append("")
            lines.append(fence(json.dumps(inp, ensure_ascii=False, indent=2)[:out_limit], "json"))
        lines.append("")

    out = state.get("output")
    if out:
        full = len(out)
        shown = out if out_limit <= 0 else out[:out_limit]
        lines.append("**输出**" + ("（已截断，完整 {} 字符）".format(full) if len(shown) < full else ""))
        lines.append("")
        lines.append(fence(shown))
        lines.append("")
    err = state.get("error")
    if err:
        lines.append("**报错**")
        lines.append("")
        lines.append(fence(json.dumps(err, ensure_ascii=False)[:out_limit]))
        lines.append("")

    lines.append("</details>")
    return "\n".join(lines)


def render(con, sess, out_limit: int, include_reasoning: bool, include_tools: bool) -> str:
    msgs = message_rows(con, sess["id"])
    md: list[str] = []

    first = msgs[0]["time_created"] if msgs else None
    last = sess["time_updated"]
    models = []
    for m in msgs:
        d = json.loads(m["data"])
        mid = d.get("modelId")
        if mid and mid not in models:
            models.append(mid)

    md.append("# {}".format(sess["title"]))
    md.append("")
    md.append("| 项目 | 值 |")
    md.append("| --- | --- |")
    md.append("| 会话 ID | `{}` |".format(sess["id"]))
    md.append("| 工作目录 | `{}` |".format(sess["directory"]))
    md.append("| 模型 | {} |".format(", ".join(models) or "-"))
    md.append("| 开始 | {} |".format(ts(first)))
    md.append("| 最后活动 | {} |".format(ts(last)))
    md.append("| 消息数 | {}（用户 {} / 助手 {}） |".format(
        len(msgs),
        sum(1 for m in msgs if json.loads(m["data"]).get("role") == "user"),
        sum(1 for m in msgs if json.loads(m["data"]).get("role") == "assistant"),
    ))
    md.append("")
    md.append("---")
    md.append("")

    turn = 0
    n_tools = 0
    for m in msgs:
        data = json.loads(m["data"])
        if not visible(data):
            continue
        role = data.get("role")
        parts = parts_of(con, m["id"])

        if role == "user":
            texts = [p.get("text", "") for p in parts if p.get("type") == "text"]
            files = [p for p in parts if p.get("type") == "file"]
            body = "\n\n".join(t.strip() for t in texts if t and t.strip())
            if not body and not files:
                continue
            turn += 1
            md.append("## {} · 用户 · {}".format(turn, ts(m["time_created"])))
            md.append("")
            if body:
                md.append(demote(body))
                md.append("")
            for f in files:
                preview = ((f.get("source") or {}).get("text") or {}).get("value")
                md.append("<details><summary>📎 附件 {}</summary>".format(f.get("filename", "")))
                md.append("")
                if preview:
                    md.append(fence(preview[:out_limit]))
                md.append("")
                md.append("</details>")
                md.append("")
            md.append("")

        elif role == "assistant":
            chunks: list[str] = []
            has_text = False
            when = datetime.datetime.fromtimestamp(m["time_created"] / 1000).strftime("%H:%M")
            for p in parts:
                t = p.get("type")
                if t in NOISE_PARTS:
                    continue
                if t == "text" and p.get("text", "").strip():
                    chunks.append(demote(p["text"].strip()))
                    has_text = True
                elif t == "reasoning" and include_reasoning and p.get("text", "").strip():
                    chunks.append(
                        "<details><summary>💭 思考</summary>\n\n{}\n\n</details>".format(
                            p["text"].strip()
                        )
                    )
                elif t == "tool" and include_tools:
                    chunks.append(tool_block(p, out_limit, when))
                    n_tools += 1
                elif t == "compaction":
                    chunks.append("> ⚠️ 上下文已自动压缩（{} → {} tokens）".format(
                        p.get("preCompactTokenCount"), p.get("truePostCompactTokenCount")))
                elif t == "file":
                    chunks.append("<details><summary>📎 附件 {}</summary>\n\n{}</details>".format(
                        p.get("filename", ""), fence(((p.get("source") or {}).get("text") or {}).get("value", "")[:out_limit])))
            if not chunks:
                continue
            # 只在助手真的“说话”时起标题；纯工具调用的消息直接接在上一段后面，
            # 否则一个回合里会出现几十个空标题。
            if has_text:
                md.append("### 🤖 助手 · {}".format(ts(m["time_created"])))
                md.append("")
            md.append("\n\n".join(chunks))
            md.append("")
            md.append("")

    md.append("---")
    md.append("")
    md.append("> 共 {} 轮对话，{} 次工具调用。由 `export_session.py` 从 ZCode 会话库导出。".format(turn, n_tools))
    md.append("")
    return "\n".join(md)


def safe_name(sess) -> str:
    d = datetime.datetime.fromtimestamp(sess["time_created"] / 1000).strftime("%Y%m%d")
    t = "".join(c for c in sess["title"] if c not in '\\/:*?"<>|').strip()[:40]
    return "{}_{}_{}.md".format(d, sess["id"][:20], t)


def main():
    ap = argparse.ArgumentParser(description="导出 ZCode 会话为 Markdown")
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--session", help="会话 ID（可用前缀）")
    ap.add_argument("--recent", type=int, help="导出最近 N 个会话")
    ap.add_argument("--directory", help="按工作目录过滤，如 D:\\study\\demo；为空则全部")
    ap.add_argument("--out", default=".", help="输出目录")
    ap.add_argument("--out-limit", type=int, default=1200, help="工具输出/入参截断字符数，0 表示不截断")
    ap.add_argument("--reasoning", action="store_true", help="包含思考过程")
    ap.add_argument("--no-tools", action="store_true", help="不包含工具调用")
    ap.add_argument("--subagents", action="store_true", help="包含子 agent 会话")
    ap.add_argument("--list", action="store_true", help="只列出会话")
    a = ap.parse_args()

    con = connect(a.db)

    if a.list:
        for s in load_sessions(con, a.directory, 50, a.subagents):
            print("{} | {} | {} | {}".format(s["id"], s["directory"], ts(s["time_updated"]), s["title"]))
        return

    targets = []
    if a.session:
        targets = [resolve_session(con, a.session)]
    else:
        n = a.recent or 1
        targets = load_sessions(con, a.directory, n, a.subagents)
    if not targets:
        sys.exit("没有可导出的会话")

    os.makedirs(a.out, exist_ok=True)
    for s in targets:
        md = render(con, s, a.out_limit, a.reasoning, not a.no_tools)
        path = os.path.join(a.out, safe_name(s))
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(md)
        print("导出 {} → {}  ({:.0f} KB)".format(s["id"], path, len(md.encode("utf-8")) / 1024))


if __name__ == "__main__":
    main()
