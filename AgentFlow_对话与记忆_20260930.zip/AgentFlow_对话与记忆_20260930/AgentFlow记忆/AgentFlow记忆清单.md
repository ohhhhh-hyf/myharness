# AgentFlow 跨会话记忆清单

导出时间：2026-09-30 14:23:19

记忆的物理形态是 chromadb 向量库（`data/{user_id}/memory/chromadb/`），本文件把库里的文档与元数据摊平成可读文本；原始库文件见同目录下的 `运行期记忆数据/`。

## 用户 `u1` ・ 1 条记忆

### 1. 小艺慧记Agent内测 ・ project

| 字段 | 值 |
| --- | --- |
| `domain` | meeting |
| `kind` | project |
| `owner` | u1 |
| `project_id` | 小艺慧记Agent |
| `project_key` | 小艺慧记Agent内测 |
| `run_count` | 2 |
| `signals` | 小艺慧记Agent内测|小艺一期复盘纪要|小艺内测推进会|小艺慧记Agent |

**记忆正文**

> 小艺慧记Agent内测 小艺慧记Agent内测 推进小艺慧记Agent内测 议题：记忆引用展示 决策：记忆引用展示放到文末；是否默认开启记忆引用已完成 主题：小艺慧记Agent、小艺慧记Agent内测 议题：小艺一期复盘纪要；小艺内测推进会 进行中：补齐记忆引用来源字段 实体：小艺慧记Agent、小艺慧记Agent内测 决策：先把任务目录整理完；记忆引用展示放到文末；是否默认开启记忆引用已完成


## 用户 `u2` ・ 2 条记忆

### 1. AlphaCore ・ project

| 字段 | 值 |
| --- | --- |
| `domain` | meeting |
| `kind` | project |
| `owner` | u2 |
| `project_id` | 项目甲 |
| `project_key` | AlphaCore |
| `run_count` | 1 |
| `signals` | AlphaCore|项目甲|甲周会 |

**记忆正文**

> AlphaCore AlphaCore 推进项目甲 AlphaCore 议题：甲进度 决策：甲继续 主题：AlphaCore 议题：甲周会 实体：AlphaCore 决策：甲继续

### 2. BetaCore ・ project

| 字段 | 值 |
| --- | --- |
| `domain` | meeting |
| `kind` | project |
| `owner` | u2 |
| `project_id` | 项目乙 |
| `project_key` | BetaCore |
| `run_count` | 1 |
| `signals` | BetaCore|项目乙|乙周会 |

**记忆正文**

> BetaCore BetaCore 推进项目乙 BetaCore 议题：乙进度 决策：乙继续 主题：BetaCore 议题：乙周会 实体：BetaCore 决策：乙继续


---

> 共 3 条记忆。由 `export_memory.py` 从 chromadb 库导出。
